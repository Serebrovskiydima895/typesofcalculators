import sys

from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QHBoxLayout, QLineEdit, QComboBox, QVBoxLayout
from PyQt5.QtWidgets import QMainWindow, QLabel


class FirstForm(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Конвертер единиц")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.input_value = QLineEdit()
        layout.addWidget(self.input_value)

        self.unit_from = QComboBox()
        self.unit_from.addItems(["см", "м", "км", "мм", "кг", "г"])
        layout.addWidget(self.unit_from)

        self.print_value = QLineEdit()
        layout.addWidget(self.print_value)

        self.unit_to = QComboBox()
        self.unit_to.addItems(["см", "м", "км", "мм", "кг", "г"])
        layout.addWidget(self.unit_to)

        self.result_label = QLabel()
        layout.addWidget(self.result_label)

        self.calculate_button = QPushButton("Конвертировать")
        layout.addWidget(self.calculate_button)

        self.calculate_button.clicked.connect(self.convert_units)

        self.central_widget.setLayout(layout)

        self.btn = QPushButton('Калькулятор', self)
        layout.addWidget(self.btn)
        self.btn.setStyleSheet('background-color: red')

        self.btn.clicked.connect(self.open_second_form)

        self.btn1 = QPushButton('Калькулятор Валют', self)
        layout.addWidget(self.btn1)
        self.btn1.setStyleSheet('background-color: red')

        self.btn1.clicked.connect(self.open_third_form)

        self.btn2 = QPushButton('Калькулятор Систем Исчесления', self)
        layout.addWidget(self.btn2)
        self.btn2.setStyleSheet('background-color: red')

        self.btn2.clicked.connect(self.open_four_form)

    def convert_units(self):
        try:
            value = float(self.input_value.text())
            unit_from = self.unit_from.currentText()
            unit_to = self.unit_to.currentText()

            # Define conversion factors
            conversion_factors = {
                "см": {"м": 0.01, "км": 0.00001, "см": 1, "мм": 10},
                "м": {"м": 1, "см": 100, "км": 0.001, "мм": 1000, },
                "км": {"км": 1, "см": 100000, "м": 1000, "мм": 1000000},
                "мм": {"см": 0.1, "мм": 1, "м": 0.001, "км": 0.000001},
                "кг": {"г": 1000},
                "г": {"кг": 0.001}
            }

            # Perform the conversion
            result = value * conversion_factors[unit_from][unit_to]
            self.print_value.setText(f"{result} {unit_to}")

        except ValueError:
            self.print_value.setText("Введите числовое значение")
        except KeyError:
            self.print_value.setText("Error")

    def open_second_form(self):
        self.second_form = SecondForm(self)
        self.second_form.show()

    def open_third_form(self):
        self.third_form = ThirdForm(self)
        self.third_form.show()

    def open_four_form(self):
        self.four_form = FourForm(self)
        self.four_form.show()


class SecondForm(QMainWindow):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle("Калькулятор")
        self.setGeometry(100, 100, 300, 300)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout()

        # Создаем строку ввода и добавляем ее в верхнюю часть макета
        self.input_line = QLineEdit()
        self.layout.addWidget(self.input_line)

        # Создаем кнопки для цифр и операций
        button_layout = QVBoxLayout()
        button_row1 = QHBoxLayout()
        button_row2 = QHBoxLayout()
        button_row3 = QHBoxLayout()
        button_row4 = QHBoxLayout()

        button_row1.addWidget(self.create_button("1"))
        button_row1.addWidget(self.create_button("2"))
        button_row1.addWidget(self.create_button("3"))
        button_row1.addWidget(self.create_button("+"))
        button_row2.addWidget(self.create_button("4"))
        button_row2.addWidget(self.create_button("5"))
        button_row2.addWidget(self.create_button("6"))
        button_row2.addWidget(self.create_button("-"))
        button_row3.addWidget(self.create_button("7"))
        button_row3.addWidget(self.create_button("8"))
        button_row3.addWidget(self.create_button("9"))
        button_row3.addWidget(self.create_button("*"))
        button_row4.addWidget(self.create_button("C"))
        button_row4.addWidget(self.create_button("0"))
        button_row4.addWidget(self.create_button("="))
        button_row4.addWidget(self.create_button("/"))

        button_layout.addLayout(button_row1)
        button_layout.addLayout(button_row2)
        button_layout.addLayout(button_row3)
        button_layout.addLayout(button_row4)

        self.layout.addLayout(button_layout)
        self.central_widget.setLayout(self.layout)

    def create_button(self, text):
        button = QPushButton(text)
        button.clicked.connect(lambda: self.on_button_click(text))
        return button

    def on_button_click(self, text):
        if text == "=":
            # Вычисляем результат выражения во вводной строке и выводим его
            try:
                result = eval(self.input_line.text())
                self.input_line.setText(str(result))
            except Exception:
                self.input_line.setText("Ошибка")
        elif text == "C":
            # Очищаем вводную строку
            self.input_line.clear()
        else:
            current_text = self.input_line.text()
            self.input_line.setText(current_text + text)


class ThirdForm(QMainWindow):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle("Калькулятор валют")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()

        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.input_value = QLineEdit()
        layout.addWidget(self.input_value)

        self.unit_from = QComboBox()
        self.unit_from.addItems(
            ["Амерекансий Доллар", "Евро", "Российский рубль", "Швейцарский франк", "Китайский юань",
             "Израильский шекель",
             "Белорусский рубль"])

        layout.addWidget(self.unit_from)

        self.print_value = QLineEdit()

        layout.addWidget(self.print_value)

        self.unit_to = QComboBox()
        self.unit_to.addItems(
            ["Амерекансий Доллар", "Евро", "Российский рубль", "Швейцарский франк", "Китайский юань",
             "Израильский шекель",
             "Белорусский рубль"])

        layout.addWidget(self.unit_to)

        self.result_label = QLabel()
        layout.addWidget(self.result_label)

        self.calculate_button = QPushButton("Конвертировать")
        layout.addWidget(self.calculate_button)

        self.calculate_button.clicked.connect(self.convert_units)

        self.central_widget.setLayout(layout)

    def convert_units(self):
        try:
            value = float(self.input_value.text())
            unit_from = self.unit_from.currentText()
            unit_to = self.unit_to.currentText()

            conversion_factors = {
                "Амерекансий Доллар": {"Евро": 0.95, "Российский рубль": 93.16, "Швейцарский франк": 0.90,
                                       "Китайский юань": 7.32, "Израильский шекель": 4.05,
                                       "Белорусский рубль": 3.29, "Амерекансий Доллар": 1},
                "Евро": {"Евро": 1, "Амерекансий Доллар": 1.07, "Российский рубль": 99.34, "Швейцарский франк": 0.96,
                         "Китайский юань": 7.75, "Израильский шекель": 4.29, "Белорусский рубль": 3.48},
                "Российский рубль": {"Евро": 0.0101, "Амерекансий Доллар": 0.0107, "Российский рубль": 1,
                                     "Швейцарский франк": 0.0097,
                                     "Китайский юань": 0.0786, "Израильский шекель": 0.44,
                                     "Белорусский рубль": 0.036},
                "Швейцарский франк": {"Евро": 1.04, "Амерекансий Доллар": 1.11, "Российский рубль": 103.08,
                                      "Швейцарский франк": 1,
                                      "Китайский юань": 8.10, "Израильский шекель": 4.33,
                                      "Белорусский рубль": 3.67},
                "Китайский юань": {"Евро": 0.13, "Амерекансий Доллар": 0.14, "Российский рубль": 12.72,
                                   "Швейцарский франк": 0.12,
                                   "Китайский юань": 1, "Израильский шекель": 0.53, "Белорусский рубль": 0.45},
                "Израильский шекель": {"Евро": 0.24, "Амерекансий Доллар": 0.26, "Российский рубль": 23.89,
                                       "Швейцарский франк": 0.23,
                                       "Китайский юань": 1.89, "Израильский шекель": 1, "Белорусский рубль": 0.85},
                "Белорусский рубль": {"Евро": 0.28, "Амерекансий Доллар": 0.30, "Российский рубль": 28.06,
                                      "Швейцарский франк": 0.27,
                                      "Китайский юань": 2.21, "Израильский шекель": 1.17, "Белорусский рубль": 1}
            }

            result = value * conversion_factors[unit_from][unit_to]
            self.print_value.setText(str(result))

        except ValueError:
            self.print_value.setText("Введите числовое значение")

        except KeyError:
            self.print_value.setText("Error")


class FourForm(QWidget):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        self.setWindowTitle('Конвертер систем счисления')
        self.setGeometry(100, 100, 400, 200)

        self.layout = QVBoxLayout()

        self.from_base_label = QLabel('Исходная система счисления:')
        self.from_base_combo = QComboBox()
        self.from_base_combo.addItems(['2', '10', '16'])
        self.from_base_combo.setCurrentIndex(1)

        self.to_base_label = QLabel('Целевая система счисления:')
        self.to_base_combo = QComboBox()
        self.to_base_combo.addItems(['2', '10', '16'])
        self.to_base_combo.setCurrentIndex(0)

        self.number_label = QLabel('Число:')
        self.number_input = QLineEdit()

        self.result_label = QLabel('Результат:')
        self.result_output = QLineEdit()
        self.result_output.setReadOnly(True)

        self.check_button = QPushButton('Проверить')
        self.convert_button = QPushButton('Конвертировать')

        self.check_button.clicked.connect(self.check_number)
        self.convert_button.clicked.connect(self.convert_number)

        top_layout = QHBoxLayout()
        top_layout.addWidget(self.from_base_label)
        top_layout.addWidget(self.from_base_combo)
        top_layout.addWidget(self.to_base_label)
        top_layout.addWidget(self.to_base_combo)

        middle_layout = QHBoxLayout()
        middle_layout.addWidget(self.number_label)
        middle_layout.addWidget(self.number_input)

        bottom_layout = QHBoxLayout()
        bottom_layout.addWidget(self.check_button)
        bottom_layout.addWidget(self.convert_button)

        self.layout.addLayout(top_layout)
        self.layout.addLayout(middle_layout)
        self.layout.addLayout(bottom_layout)
        self.layout.addWidget(self.result_label)
        self.layout.addWidget(self.result_output)

        self.setLayout(self.layout)

    def check_number(self):
        number = self.number_input.text()
        from_base = int(self.from_base_combo.currentText())
        try:
            int(number, from_base)
            self.result_output.setText("Число подходит к данной системе счисления.")
        except ValueError:
            self.result_output.setText("Число не подходит к данной системе счисления.")

    def convert_number(self):
        def convert_number(number, from_base, to_base):
            try:
                decimal_number = int(number, from_base)

                converted_number = format(decimal_number, 'x' if to_base == 16 else 'b' if to_base == 2 else 'd')

                return converted_number
            except ValueError:
                return "Неверное число"

        number = self.number_input.text()
        from_base = int(self.from_base_combo.currentText())
        to_base = int(self.to_base_combo.currentText())
        converted = convert_number(number, from_base, to_base)
        self.result_output.setText(converted)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = FirstForm()
    ex.show()
    sys.exit(app.exec())
